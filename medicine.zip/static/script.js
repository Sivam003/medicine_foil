document.getElementById('uploadButton').addEventListener('click', () => {
    document.getElementById('fileInput').click();
});

document.getElementById('fileInput').addEventListener('change', async function() {
    const file = this.files[0];
    if (!file) return;

    const formData = new FormData();
    formData.append('file', file);

    const response = await fetch('/upload', {
        method: 'POST',
        body: formData
    });

    const result = await response.json();
    if (response.ok) {
        document.getElementById('result').innerHTML = `
            <h3>Identified Medicine: ${result.medicine}</h3>
            <p>Confidence Score: ${result.score}</p>
        `;
    } else {
        document.getElementById('result').innerHTML = `
            <h3>Error: ${result.error}</h3>
        `;
    }
});
